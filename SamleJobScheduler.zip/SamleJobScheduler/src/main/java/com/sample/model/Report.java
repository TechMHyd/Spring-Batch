package com.sample.model;



import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "record")
public class Report {

		private int id;
		private String impressions;
		public int getId() {
			return id;
		}
		@Override
		public String toString() {
			return "Report [id=" + id + ", impressions=" + impressions + "]";
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getImpressions() {
			return impressions;
		}
		public void setImpressions(String impressions) {
			this.impressions = impressions;
		}
		
}
